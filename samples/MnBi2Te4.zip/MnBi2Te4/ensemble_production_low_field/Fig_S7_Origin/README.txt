Fig. S7: cumulative first equator crossing, not near-pole occupancy or final reversal.
First column X: elapsed pulse centers (0--30). Other columns Y: percentage.
Directions files: 300 trajectories per column. Pooled files: both reversal directions, 600 trajectories per temperature.
Never-crossed trajectories remain in the denominator. Targets are selected via xy+ -> +z, xy- -> -z.
The first-crossing event depends on initial pole, so the erroneous target labels do not alter these event times.
Bin 30 includes crossings after the last pulse center through the final observation time (5.1 ns).
